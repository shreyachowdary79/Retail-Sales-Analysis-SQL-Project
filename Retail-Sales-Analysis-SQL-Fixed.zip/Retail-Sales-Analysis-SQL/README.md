# Retail Sales Analysis | PostgreSQL

## Project Overview

This project uses PostgreSQL to clean and analyze retail transaction data and answer business questions about sales, customer purchasing patterns, product categories, monthly performance, and shopping-time trends.

## Objectives

- Prepare a retail sales table and review data quality.
- Explore transaction volume, customer counts, and product categories.
- Analyze sales by category, gender, month, customer, and time of day.
- Use SQL aggregation, date filtering, CTEs, and window functions to answer business questions.

## Tools

- PostgreSQL
- SQL (data cleaning, filtering, aggregation, CTEs, window functions)

## Repository Files

- `retail_sales.csv` — retail transaction dataset.
- `retail_sales_analysis.sql` — table creation, data-quality checks, and 10 analysis queries.

## Dataset Columns

`transaction_id`, `sale_date`, `sale_time`, `customer_id`, `gender`, `age`, `category`, `quantity`, `price_per_unit`, `cogs`, and `total_sale`.

## How to Run

1. Open PostgreSQL using pgAdmin or another SQL client.
2. Run `CREATE DATABASE retail_sales_db;` from the top of the SQL script as a separate command. Connect to `retail_sales_db`.
3. Run the table-creation section of `retail_sales_analysis.sql`.
4. Import `retail_sales.csv` into `retail_sales` using the client’s CSV import tool. Keep the column order consistent with the table and enable the option to treat the first row as headers.
5. Run the remaining SQL queries. Review the data-quality results before running the optional `DELETE` statement.

> Note: `CREATE DATABASE` must be run while connected to a different database (such as `postgres`), not inside a transaction block. Import the CSV before running the analysis queries.

## Business Questions

1. Which transactions occurred on 5 November 2022?
2. Which Clothing transactions had quantity greater than four in November 2022?
3. What are total sales and transaction counts by category?
4. What is the average age of customers purchasing Beauty products?
5. Which transactions exceeded 1,000 in sales?
6. How many transactions occurred by gender and category?
7. Which month had the highest average transaction value in each year?
8. Who are the top five customers by total sales?
9. How many unique customers purchased from each category?
10. How are transactions distributed across morning, afternoon, and evening shifts?

## Skills Demonstrated

SQL querying, data validation, data cleaning, exploratory data analysis, business-question framing, aggregation, date/time analysis, Common Table Expressions (CTEs), and window functions.

## Important Note

The SQL file provides the analysis queries; results depend on successfully importing the dataset and running the script in PostgreSQL. Add verified query results or screenshots to this repository if you want to publish specific numerical findings.
