-- Retail Sales Analysis | PostgreSQL
-- Step 1: Run CREATE DATABASE separately, then connect to retail_sales_db.
CREATE DATABASE retail_sales_db;

-- Step 2: After connecting to retail_sales_db, run the remaining statements.
DROP TABLE IF EXISTS retail_sales;

CREATE TABLE retail_sales (
    transaction_id INT PRIMARY KEY,
    sale_date DATE,
    sale_time TIME,
    customer_id INT,
    gender VARCHAR(15),
    age INT,
    category VARCHAR(35),
    quantity INT,
    price_per_unit NUMERIC(12,2),
    cogs NUMERIC(12,2),
    total_sale NUMERIC(12,2)
);

-- Import retail_sales.csv into retail_sales using your SQL client’s CSV import tool.
-- Match columns in this order; the supplied CSV header is standardized to transaction_id and quantity.

-- Quick data checks
SELECT * FROM retail_sales LIMIT 10;
SELECT COUNT(*) AS total_transactions FROM retail_sales;
SELECT COUNT(DISTINCT customer_id) AS unique_customers FROM retail_sales;
SELECT DISTINCT category FROM retail_sales ORDER BY category;

-- Data quality: inspect missing values before deleting anything
SELECT *
FROM retail_sales
WHERE transaction_id IS NULL OR sale_date IS NULL OR sale_time IS NULL
   OR customer_id IS NULL OR gender IS NULL OR age IS NULL OR category IS NULL
   OR quantity IS NULL OR price_per_unit IS NULL OR cogs IS NULL OR total_sale IS NULL;

-- Optional cleanup. Primary-key values cannot be NULL; keep this for other missing fields.
DELETE FROM retail_sales
WHERE sale_date IS NULL OR sale_time IS NULL OR customer_id IS NULL
   OR gender IS NULL OR age IS NULL OR category IS NULL
   OR quantity IS NULL OR price_per_unit IS NULL OR cogs IS NULL OR total_sale IS NULL;

-- Q1: Transactions on 5 November 2022
SELECT * FROM retail_sales WHERE sale_date = DATE '2022-11-05';

-- Q2: Clothing transactions with quantity greater than 4 in November 2022
SELECT *
FROM retail_sales
WHERE category = 'Clothing'
  AND sale_date >= DATE '2022-11-01' AND sale_date < DATE '2022-12-01'
  AND quantity > 4;

-- Q3: Total sales and transaction count by category
SELECT category, SUM(total_sale) AS total_sales, COUNT(*) AS total_transactions
FROM retail_sales
GROUP BY category
ORDER BY total_sales DESC;

-- Q4: Average customer age for Beauty purchases
SELECT ROUND(AVG(age), 2) AS average_customer_age
FROM retail_sales
WHERE category = 'Beauty';

-- Q5: Transactions with sales above 1000
SELECT * FROM retail_sales WHERE total_sale > 1000 ORDER BY total_sale DESC;

-- Q6: Transaction count by gender and category
SELECT category, gender, COUNT(*) AS total_transactions
FROM retail_sales
GROUP BY category, gender
ORDER BY category, gender;

-- Q7: Best month by average transaction value in each year (ties included)
WITH monthly_sales AS (
    SELECT EXTRACT(YEAR FROM sale_date)::INT AS year,
           EXTRACT(MONTH FROM sale_date)::INT AS month,
           AVG(total_sale) AS average_sale,
           RANK() OVER (
               PARTITION BY EXTRACT(YEAR FROM sale_date)
               ORDER BY AVG(total_sale) DESC
           ) AS month_rank
    FROM retail_sales
    GROUP BY EXTRACT(YEAR FROM sale_date), EXTRACT(MONTH FROM sale_date)
)
SELECT year, month, ROUND(average_sale, 2) AS average_sale
FROM monthly_sales
WHERE month_rank = 1
ORDER BY year;

-- Q8: Top five customers by total sales
SELECT customer_id, SUM(total_sale) AS total_sales
FROM retail_sales
GROUP BY customer_id
ORDER BY total_sales DESC
LIMIT 5;

-- Q9: Unique customers by product category
SELECT category, COUNT(DISTINCT customer_id) AS unique_customers
FROM retail_sales
GROUP BY category
ORDER BY category;

-- Q10: Transaction count by time-of-day shift
WITH transactions_by_shift AS (
    SELECT CASE
        WHEN sale_time < TIME '12:00:00' THEN 'Morning'
        WHEN sale_time <= TIME '17:00:00' THEN 'Afternoon'
        ELSE 'Evening'
    END AS shift
    FROM retail_sales
)
SELECT shift, COUNT(*) AS total_transactions
FROM transactions_by_shift
GROUP BY shift
ORDER BY CASE shift WHEN 'Morning' THEN 1 WHEN 'Afternoon' THEN 2 ELSE 3 END;
